import {
  CloudWatchLogsClient,
  DeleteLogGroupCommand,
} from "@aws-sdk/client-cloudwatch-logs";
import { makeResponse } from "/opt/nodejs/helper.mjs";

export const deleteResource = async (
  resourceIdentifier,
  credentials,
  options = {},
) => {
  try {
    const client = new CloudWatchLogsClient({
      credentials,
    });
    const response = await client.send(
      new DeleteLogGroupCommand({ logGroupName: resourceIdentifier }),
    );
    return makeResponse(200, {
      message: "Resource deleted successfully",
    });
  } catch (error) {
    if (error?.name === "ResourceNotFoundException") {
      return makeResponse(404, {
        message: "Resource does not exist",
      });
    }
  }
};
